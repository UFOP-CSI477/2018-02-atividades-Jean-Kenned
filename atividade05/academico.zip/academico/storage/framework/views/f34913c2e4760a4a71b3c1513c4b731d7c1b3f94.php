<?php $__env->startSection('conteudo'); ?>

  <h1>Editar Cidade</h1>
  <form action="<?php echo e(route(cidades.update),$cidade->id); ?>" method="post">

    <?php echo csrf_field(); ?>

    <p>Nome: <input type="text" name="nome" value="<?php echo e($cidade->nome); ?>"> </p>
    <p>Estado:</p>

    <select name="estado_id">
      <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($e->id); ?>"><?php echo e($e->nome); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <input type="submit" name="btnSalvar" value="Incluir">
  </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
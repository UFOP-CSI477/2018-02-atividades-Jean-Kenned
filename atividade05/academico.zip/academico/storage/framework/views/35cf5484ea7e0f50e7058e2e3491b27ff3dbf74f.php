<?php $__env->startSection('conteudo'); ?>

  <h1>Cidades</h1>
  <p><a href="<?php echo e(route('cidades.create')); ?>">Inserir nova cidade</a></p>

<!--aqui usa sintaxe blade-->
  <?php $__currentLoopData = $cidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <p><?php echo e($c -> nome); ?>-<?php echo e($c->estado->sigla); ?></p>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
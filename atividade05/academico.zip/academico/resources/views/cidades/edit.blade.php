@extends('layout')

@section('conteudo')

  <h1>Editar Cidade</h1>
  <form action="{{route(cidades.update),$cidade->id}}" method="post">

    @csrf

    <p>Nome: <input type="text" name="nome" value="{{$cidade->nome}}"> </p>
    <p>Estado:</p>

    <select name="estado_id">
      @foreach($estados as $e)
        <option value="{{$e->id}}">{{$e->nome}}</option>
      @endforeach
    </select>

    <input type="submit" name="btnSalvar" value="Incluir">
  </form>

@endsection

<?php $__env->startSection('conteudo'); ?>

  <h1>Estado</h1>

<!--aqui usa sintaxe blade-->
  <h1>Estado:  <?php echo e($estado->nome); ?>-<?php echo e($estado->sigla); ?></h1>
  <p>Código: <?php echo e($estado->id); ?></p>
  <p>Sigla:<?php echo e($estado->sigla); ?></p>


  <!--<a href="/estados">Voltar</a> ou -->
  <a href="<?php echo e(route('estados.index')); ?>">Voltar</a>
  <a href="<?php echo e(route('estados.edit',$estado->id)); ?>">Editar</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('conteudo'); ?>

  <h1>Alunos</h1>

<!--aqui usa sintaxe blade-->
  <?php $__currentLoopData = $alunos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <p>Nome:<?php echo e($a -> nome); ?></p>
    <p>Matricula:<?php echo e($a -> matricula); ?></p>
    <p>Email:<?php echo e($a -> email); ?></p>
    <p>Cidade:<?php echo e($a->cidade->nome); ?>-<?php echo e($a->cidade->estado->sigla); ?> </p>
    <br>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
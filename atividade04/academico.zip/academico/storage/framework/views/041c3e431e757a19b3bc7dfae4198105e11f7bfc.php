<?php $__env->startSection('conteudo'); ?>

  <h1>Estados</h1>

<!--aqui usa sintaxe blade-->
  <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<!--    <p><a href="/estados/<?php echo e($e->id); ?>"> <?php echo e($e -> nome); ?>-<?php echo e($e -> sigla); ?></a></p> -->
  <p><a href="<?php echo e(route('estados.show',$e->id)); ?>"> <?php echo e($e -> nome); ?>-<?php echo e($e -> sigla); ?></a></p>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
@extends('layout')

@section('conteudo')

  <h1>Estados</h1>

<!--aqui usa sintaxe blade-->
  @foreach($estados as $e)

<!--    <p><a href="/estados/{{$e->id}}"> {{ $e -> nome}}-{{ $e -> sigla}}</a></p> -->
  <p><a href="{{route('estados.show',$e->id)}}"> {{ $e -> nome}}-{{ $e -> sigla}}</a></p>
  @endforeach

@endsection

<?php $__env->startSection('conteudo'); ?>

  <h1>Inserir Estados</h1>
  <form action="/estados" method="post">

    <?php echo csrf_field(); ?>

    <p>Nome: <input type="text" name="nome"> </p>
    <p>Sigla: <input type="text" name="sigla"> </p>

    <input type="submit" name="btnSalvar" value="Incluir">
  </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
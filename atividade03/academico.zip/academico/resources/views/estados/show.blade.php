@extends('layout')

@section('conteudo')

  <h1>Estado</h1>

<!--aqui usa sintaxe blade-->
  <h1>Estado:  {{$estado->nome}}-{{$estado->sigla}}</h1>
  <p>Código: {{$estado->id}}</p>
  <p>Sigla:{{$estado->sigla}}</p>


  <!--<a href="/estados">Voltar</a> ou -->
  <a href="{{route('estados.index')}}">Voltar</a>
  <a href="{{route('estados.edit',$estado->id)}}">Editar</a>
@endsection

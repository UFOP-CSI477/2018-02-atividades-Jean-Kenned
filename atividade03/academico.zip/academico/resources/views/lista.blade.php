<!-- <!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <h1>Lista da Turma</h1>
    <a href="/">Principal</a>
  </body>
</html> -->

@extends('layout')

<!--
@section('titulo')
    Lista de pessoas da turma

@endsection
-->

@section('titulo','Lista de pessoas da turma')


@section('conteudo')
    <h1>Lista da Turma</h1>

    <!-- com a notação do blade é possivel evitar abrir tags php para os lacos  -->
    @foreach($alunos as $a)
      <li>{{ $a }}</li>
    @endforeach

@endsection

<!-- <!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>

    <h1>Informações sobre a aplicação</h1>
    <a href="/">Principal</a> -->

    @extends('layout')

    @section('conteudo')
        <h1>Informações sobre a aplicação</h1>

    @endsection

  <!-- </body>
</html> -->

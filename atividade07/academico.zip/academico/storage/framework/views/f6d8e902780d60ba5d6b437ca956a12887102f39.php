<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title><?php echo $__env->yieldContent('titulo','Sistema Acadêmico'); ?></title>
    <!--posso setar um titulo, se nada for setado sera sistema academico-->
  </head>
  <body>

    <!--Flash: mensagem //-->
    <?php if(Session::has('mensagem')): ?>
      <p><strong><?php echo e(Session::get('mensagem')); ?></strong></p>
    <?php endif; ?>

    <!--lista nao numerada-->
    <ul>
      <li><a href="/">Principal</a></li>
      <li><a href="/lista">Lista</a></li>
      <li><a href="/info">Informações</a></li>
      <li><a href="/contato">Contato</a></li>
    </ul>

    <!-- quando tiver @ é um comando do blade-->


    <!-- secao de conteudo-->
    <?php echo $__env->yieldContent('conteudo'); ?>

  </body>
</html>

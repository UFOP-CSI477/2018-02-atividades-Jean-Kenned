<?php $__env->startSection('conteudo'); ?>

  <h1>Inserir Aluno</h1>
  <form action="/alunos" method="post">

    <?php echo csrf_field(); ?>
    <p>Nome: <input type="text" name="nome"> </p>
    <p>Matricula: <input type="text" name="matricula"></p>
    <p>Email: <input type="text" name="email"></p>
    <p>Cidade:</p>

    <select name="cidade_id">
      <?php $__currentLoopData = $cidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($c->id); ?>"><?php echo e($c->nome); ?>-<?php echo e($c->estado->sigla); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <input type="submit" name="btnSalvar" value="Incluir">
  </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
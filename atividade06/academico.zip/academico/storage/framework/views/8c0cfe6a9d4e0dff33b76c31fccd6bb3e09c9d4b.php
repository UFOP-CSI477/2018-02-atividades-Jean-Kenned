<?php $__env->startSection('conteudo'); ?>

  <h1>Editar Aluno</h1>
  <form action="<?php echo e(route('alunos.update',$aluno->id)); ?>" method="post">

    <?php echo csrf_field(); ?>
  <?php echo method_field('PATCH'); ?>
    <p>Nome: <input type="text" name="nome" value="<?php echo e($aluno->nome); ?>"> </p>
    <p>matricula: <input type="text" name="matricula" value="<?php echo e($aluno->matricula); ?>"> </p>
    <p>email: <input type="text" name="email" value="<?php echo e($aluno->email); ?>"> </p>
    <p>cidade:</p>

    <select name="cidade_id">
      <?php $__currentLoopData = $cidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php if($c->id == $aluno->cidade_id): ?>
          <option value="<?php echo e($c->id); ?>" selected><?php echo e($c->nome); ?>-<?php echo e($c->estado->sigla); ?></option>

        <?php else: ?>
          <option value="<?php echo e($c->id); ?>"><?php echo e($c->nome); ?></option>

        <?php endif; ?>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </select>

    <input type="submit" name="btnSalvar" value="Incluir">
  </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
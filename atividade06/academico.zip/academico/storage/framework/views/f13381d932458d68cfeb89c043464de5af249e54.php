<!-- <!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <h1>Lista da Turma</h1>
    <a href="/">Principal</a>
  </body>
</html> -->



<!--
<?php $__env->startSection('titulo'); ?>
    Lista de pessoas da turma

<?php $__env->stopSection(); ?>
-->

<?php $__env->startSection('titulo','Lista de pessoas da turma'); ?>


<?php $__env->startSection('conteudo'); ?>
    <h1>Lista da Turma</h1>

    <!-- com a notação do blade é possivel evitar abrir tags php para os lacos  -->
    <?php $__currentLoopData = $alunos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($a); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
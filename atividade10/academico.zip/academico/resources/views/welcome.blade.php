<!-- <!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Sistema Acadêmico</title>
  </head>
  <body> -->
@extends('layout')

@section('conteudo')
    <h1>Verifique os estados, cidades e alunos cadastrados. Insira,edite ou remova cada um deles conforme desejar.</h1>

@endsection
<!--
    <a href="/info">Informações</a>
    <a href="/lista">Lista</a>

  </body>
</html> -->

<!-- <!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Sistema Acadêmico</title>
  </head>
  <body> -->


<?php $__env->startSection('conteudo'); ?>
    <h1>Verifique os estados, cidades e alunos cadastrados. Insira,edite ou remova cada um deles conforme desejar.</h1>

<?php $__env->stopSection(); ?>
<!--
    <a href="/info">Informações</a>
    <a href="/lista">Lista</a>

  </body>
</html> -->

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
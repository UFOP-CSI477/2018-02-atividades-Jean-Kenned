<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    You are logged in!
                    <p>Seja vem vindo <?php echo e($user->name); ?></p>
                    <p>Seu id de usuário é:<?php echo e($id); ?></p>
                    <p>Seu email é: <?php echo e($user->email); ?></p>
                    <p>O registro dessa conta foi feito em:<?php echo e($user->created_at); ?></p>


                    <a href="/">Voltar</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
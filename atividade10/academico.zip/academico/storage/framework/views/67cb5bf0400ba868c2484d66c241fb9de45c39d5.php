<!-- <!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>

    <h1>Informações sobre a aplicação</h1>
    <a href="/">Principal</a> -->

    

    <?php $__env->startSection('conteudo'); ?>
        <h1>Informações sobre a aplicação</h1>

    <?php $__env->stopSection(); ?>

  <!-- </body>
</html> -->

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>@yield('titulo','Sistema Acadêmico')</title>
    <!--posso setar um titulo, se nada for setado sera sistema academico-->
  </head>
  <body>

    <!--Flash: mensagem //-->
    @if (Session::has('mensagem'))
      <p><strong>{{Session::get('mensagem')}}</strong></p>
    @endif

    <!--lista nao numerada-->
    <ul>
      <li><a href="/">Principal</a></li>
      <li><a href="/lista">Lista</a></li>
      <li><a href="/info">Informações</a></li>
      <li><a href="/contato">Contato</a></li>
    </ul>

    <!-- quando tiver @ é um comando do blade-->


    <!-- secao de conteudo-->
    @yield('conteudo')

  </body>
</html>

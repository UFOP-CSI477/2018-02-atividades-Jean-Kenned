<?php $__env->startSection('conteudo'); ?>

<!--aqui usa sintaxe blade-->
  <h1>Aluno:  <?php echo e($aluno->nome); ?></h1>
  <p>Matricula:  <?php echo e($aluno->matricula); ?></p>
  <p>Email:  <?php echo e($aluno->email); ?></p>
  <p>Código: <?php echo e($aluno->id); ?></p>
  <p>Cidade:<?php echo e($aluno->cidade->nome); ?>-<?php echo e($aluno->cidade->estado->sigla); ?></p>



  <!--<a href="/estados">Voltar</a> ou -->
  <a href="<?php echo e(route('alunos.index')); ?>">Voltar</a>
  <a href="<?php echo e(route('alunos.edit',$aluno->id)); ?>">Editar</a>


  <form  action="<?php echo e(route('alunos.destroy',$aluno->id)); ?>" method="post" onsubmit="return confirm('Confirma exclusão do aluno: <?php echo e($aluno->nome); ?>?');">

    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <input type="submit" value="Excluir">

  </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>